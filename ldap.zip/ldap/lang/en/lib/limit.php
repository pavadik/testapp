<?php
$MESS["LDAP_LIMIT_USER_LIMIT_EXCEEDED"] = "You have reached maximum AD/LDAP users (#LIMIT#) allowed by your license. Please upgrade to add more users.";
