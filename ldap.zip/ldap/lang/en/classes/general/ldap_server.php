<?php

$MESS ['LDAP_ERR_NAME'] = "Name";
$MESS ['LDAP_ERR_SERVER'] = "AD/LDAP server address";
$MESS ['LDAP_ERR_PORT'] = "AD/LDAP server port";
$MESS ['LDAP_ERR_BASE_DN'] = "Tree root (Base DN)";
$MESS ['LDAP_ERR_GROUP_FILT'] = "User group filter";
$MESS ['LDAP_ERR_GROUP_ATTR'] = "Group identifier attribute";
$MESS ['LDAP_ERR_USER_FILT'] = "User filter";
$MESS ['LDAP_ERR_USER_ATTR'] = "User identifier attribute";
$MESS ['LDAP_ERR_EMPTY'] = "Field is empty:";


?>