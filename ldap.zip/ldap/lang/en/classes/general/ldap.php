<?php
$MESS["LDAP_USER_LIMIT_EXCEEDED_EVENT_TYPE"] = "Maximum AD/LDAP users reached";
