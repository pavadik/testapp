<?
$MESS ['LDAP_MODULE_NAME'] = "AD/LDAP connector";
$MESS ['LDAP_MODULE_DESC'] = "Connector module for AD/LDAP";
$MESS ['LDAP_UNINSTALL_TITLE'] = "AD/LDAP connector module uninstallation";
$MESS ['LDAP_UNINSTALL_WARNING'] = "Warning! The module will be uninstalled.";
$MESS ['LDAP_UNINSTALL_SAVEDATA'] = "To save the data stored in the database tables, check the \"Save Tables\" checkbox";
$MESS ['LDAP_UNINSTALL_SAVETABLE'] = "Save tables";
$MESS ['LDAP_UNINSTALL_DEL'] = "Uninstall";
$MESS ['LDAP_UNINSTALL_ERROR'] = "Error deleting:";
$MESS ['LDAP_UNINSTALL_COMPLETE'] = "Uninstallation complete.";
$MESS ['LDAP_INSTALL_BACK'] = "Back to the module management";
$MESS ['LDAP_MOD_INST_ERROR'] = "Error installing AD/LDAP connector module";
$MESS ['LDAP_MOD_INST_ERROR_PHP'] = "For the correct functioning of the module the PHP with LDAP module should be installed. Please contact your system administrator.";
$MESS ['LDAP_INSTALL_TITLE'] = "AD/LDAP connector module installation";
?>