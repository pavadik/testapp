<?
$MESS ['LDAP_ENTER_LOGIN_AND_PASS'] = "Please enter in dialog box your name and password you use in local network";
$MESS ['LDAP_ENTER_LOGIN_AND_PASS2'] = "Please enter your name and password you use in local network";
?>