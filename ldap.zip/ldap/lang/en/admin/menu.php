<?
$MESS['LDAP_MENU_SERVERS'] = "Servers";
$MESS['LDAP_MENU_SERVERS_ALT'] = "Setting properties of Active Directory and LDAP servers";
?>