<?
$MESS ['LDAP_ADMIN_TITLE'] = "Active Directory / LDAP server settings";
$MESS ['LDAP_ADMIN_DEL_ERR'] = "Error deleting the server settings.";
$MESS ['LDAP_ADMIN_F_ACT'] = "Active";
$MESS ['LDAP_ADMIN_F_ACT_ANY'] = "(any)";
$MESS ['LDAP_ADMIN_F_NAME'] = "Name";
$MESS ['LDAP_ADMIN_NAVSTRING'] = "Servers";
$MESS ['LDAP_ADMIN_TSTAMP'] = "Modified";
$MESS ['LDAP_ADMIN_NAME'] = "Name";
$MESS ['LDAP_ADMIN_ACT'] = "Act.";
$MESS ['LDAP_ADMIN_CODE'] = "Mnemonic code";
$MESS ['LDAP_ADMIN_SERV'] = "Server";
$MESS ['SAVE_ERROR'] = "Error updating record #";
$MESS ['LDAP_ADMIN_ACTIONS'] = "Actions";
$MESS ['LDAP_ADMIN_CHANGE'] = "Modify server settings";
$MESS ['LDAP_ADMIN_CHANGE_LINK'] = "Modify";
$MESS ['LDAP_ADMIN_DEL_ALT'] = "Delete server";
$MESS ['LDAP_ADMIN_DEL_LINK'] = "Delete";
$MESS ['LDAP_ADMIN_EMPTY'] = "List is empty";
$MESS ['LDAP_ADMIN_TOTAL'] = "Total:";
$MESS ['LDAP_ADMIN_DEL_CONF'] = "Server will be deleted and all the users registered through it won\'t be able to authorize anymore. Delete anyway?";
$MESS ['LDAP_ADMIN_SYNC'] = "Synchronize";
$MESS ['LDAP_ADMIN_SYNC_PERIOD'] = "Synchronization period";
$MESS ['LDAP_ADMIN_SYNC_LAST'] = "Last synchronized";
?>