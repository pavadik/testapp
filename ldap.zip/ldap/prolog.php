<?
define("ADMIN_MODULE_NAME", "ldap");
define("ADMIN_MODULE_ICON", "<img src=\"/bitrix/images/ldap/ldap.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\""."LDAP"."\" title=\""."LDAP"."\">");
?>