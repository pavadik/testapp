<?
$ldap_default_option = array(
	"group_limit" => "0",
	"use_ntlm" => "N",
   	"ntlm_varname"  => "REMOTE_USER",
   	"ntlm_default_server" => "0",
	"add_user_when_auth" => "Y",
	"default_email" => "no@email",
	"bitrixvm_auth_support" => "N",
	"bitrixvm_auth_net" => "",
	"ntlm_auth_without_prefix" => "Y"
);
?>
