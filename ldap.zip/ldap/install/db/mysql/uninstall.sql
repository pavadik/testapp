drop table b_ldap_group;
drop table b_ldap_server;