<?
$arModuleVersion = array(
	"VERSION" => "21.0.0",
	"VERSION_DATE" => "2021-03-16 17:30:00"
);
?>